//! GPIO API foundation.
//!
//! Pin routing is intentionally not guessed. The XMC4700 has per-pin
//! alternate-function selections and the Relax Kit board exposes several
//! possible LED/display routes. The concrete register backend is the next
//! hardware implementation step.

use core::ptr::{write_volatile};

const PORT0_BASE: usize = 0x4802_8000;
const PORT1_BASE: usize = 0x4802_8100;
const PORT2_BASE: usize = 0x4802_8200;
const PORT3_BASE: usize = 0x4802_8300;
const PORT4_BASE: usize = 0x4802_8400;
const PORT5_BASE: usize = 0x4802_8500;
const PORT6_BASE: usize = 0x4802_8600;
const PORT7_BASE: usize = 0x4802_8700;
const PORT8_BASE: usize = 0x4802_8800;
const PORT9_BASE: usize = 0x4802_8900;
// Port 10-13 existieren nicht
const PORT14_BASE: usize = 0x4802_8E00;
const PORT15_BASE: usize = 0x4802_8F00;

const OMR: usize = 0x04; // Output Modification Register
const IOCR8: usize = 0x18; // Input/Output Control Register für Pins 8..11

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Level {
    Low,
    High,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Direction {
    Input,
    Output,
}

/// Describes a GPIO pin after the board-specific pin mux has been configured.
pub struct Pin {
    port: u8,
    pin: u8,
}

impl Pin {
    /// Construct a pin descriptor. This is an internal low-level escape hatch;
    /// application code should use board pin constants when those are added.
    pub const unsafe fn new_unchecked(port: u8, pin: u8) -> Self {
        Self { port, pin }
    }

    pub const fn port(&self) -> u8 {
        self.port
    }
    pub const fn number(&self) -> u8 {
        self.pin
    }
    pub const fn port_adr(&self) -> *mut u32 {
        match self.port {
            0 => PORT0_BASE as *mut u32,
            1 => PORT1_BASE as *mut u32,
            2 => PORT2_BASE as *mut u32,
            3 => PORT3_BASE as *mut u32,
            4 => PORT4_BASE as *mut u32,
            5 => PORT5_BASE as *mut u32,
            6 => PORT6_BASE as *mut u32,
            7 => PORT7_BASE as *mut u32,
            8 => PORT8_BASE as *mut u32,
            9 => PORT9_BASE as *mut u32,
            14 => PORT14_BASE as *mut u32,
            15 => PORT15_BASE as *mut u32,
            _ => panic!("Invalid port"),
        }
    }
    pub const fn owr_adr(&self) -> *mut u32 {
        unsafe { self.port_adr().add(OMR) }
    }
}

/// Output pin handle.
///
/// Register writes are not implemented in this scaffold yet; methods are
/// marked as TODO rather than silently writing guessed register addresses.
pub struct Output {
    pin: Pin,
}

impl Output {
    pub fn new(pin: Pin, _initial: Level) -> Self {
        // TODO: configure IOCR, PDR and output latch using XMC4700 PAC.
        Self { pin }
    }

    pub fn set_level(&mut self, level: Level) {
        let owr_adr = self.pin.owr_adr();

        // Setze oder lösche das Bit basierend auf dem gewünschten Pegel
        let pin_bit = 1 << self.pin.pin;
        let set_bit = if level == Level::High { pin_bit } else { 0 };
        let clear_bit = if level == Level::Low { pin_bit } else { 0 };

        unsafe {
            // Setze den Pin auf High (wenn level == Level::High)
            if set_bit != 0 {
                write_volatile(owr_adr, set_bit);
            }
            // Setze den Pin auf Low (wenn level == Level::Low)
            if clear_bit != 0 {
                write_volatile(owr_adr.add(16), clear_bit); // OMR-Clear-Register (Offset 16)
            }
        }
    }

    pub fn toggle(&mut self) {
        let owr_adr = self.pin.owr_adr();
        unsafe { write_volatile(owr_adr, (1 << self.pin.pin) | (1 << (self.pin.pin + 16))) }
    }

    pub const fn pin(&self) -> &Pin {
        &self.pin
    }
}
